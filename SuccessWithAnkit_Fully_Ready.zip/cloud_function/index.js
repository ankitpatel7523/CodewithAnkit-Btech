const functions=require('firebase-functions');
const express=require('express');
const nodemailer=require('nodemailer');
const cors=require('cors');
const app=express();
app.use(cors({origin:true}));
app.use(express.json());

const OWNER="smartstudyankit@gmail.com";
const USER=functions.config().email.user;
const PASS=functions.config().email.pass;

const t=nodemailer.createTransport({service:'gmail',auth:{user:USER,pass:PASS}});

app.post('/sendUserNotification',async(req,res)=>{
 const {name,college,email,phone}=req.body||{};
 if(!name||!email)return res.status(400).send("Missing fields");
 try{
  await t.sendMail({
    from:USER, to:OWNER, subject:"New Login",
    text:`User Login:
Name: ${name}
College: ${college}
Email: ${email}
Phone: ${phone}
Time: ${new Date().toLocaleString()}
`
  });
  res.send({ok:true});
 }catch(e){res.status(500).send(e.toString());}
});

exports.api=functions.https.onRequest(app);
