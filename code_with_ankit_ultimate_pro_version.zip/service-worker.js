
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open('cwa-store').then(cache => {
      return cache.addAll([
        'index.html',
        'logo.png',
        'upi_qr_code.png'
      ]);
    })
  );
});

self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(response => response || fetch(e.request))
  );
});
